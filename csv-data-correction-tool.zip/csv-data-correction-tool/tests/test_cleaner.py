import pandas as pd

import cleaner as cl


def _df():
    return pd.DataFrame(
        {
            "city": ["  Paris", "paris ", "PARIS", None, "Rome", "Rome", "Rome", "Rome", "Rome", "Rome"],
            "price": [10.0, 12.0, 11.0, 13.0, 12.0, 11.0, 10.0, None, 9999.0, 9999.0],
        }
    )


def test_profile_counts():
    p = cl.profile(_df())
    assert p["rows"] == 10
    assert p["missing_cells"] == 2
    assert p["duplicate_rows"] == 1
    assert p["outliers"] == 2  # both 9999 rows


def test_text_cleaning_standardises_values():
    out, log = cl.apply_cleaning(_df(), {"strip_text": True, "text_case": "title"})
    assert out["city"].dropna().tolist() == ["Paris", "Paris", "Paris"] + ["Rome"] * 6
    assert not log.empty


def test_drop_duplicates():
    out, log = cl.apply_cleaning(_df(), {"drop_duplicates": True})
    assert len(out) == 9
    assert log.iloc[0]["rows_affected"] == 1


def test_missing_median_fill_and_drop():
    out, _ = cl.apply_cleaning(_df(), {"missing": {"price": ("median", "")}})
    assert out["price"].isna().sum() == 0
    out, _ = cl.apply_cleaning(_df(), {"missing": {"city": ("drop rows", "")}})
    assert len(out) == 9


def test_outlier_cap_and_remove():
    out, _ = cl.apply_cleaning(_df(), {"outliers": {"price": "remove rows"}})
    assert len(out) == 8
    capped, _ = cl.apply_cleaning(_df(), {"outliers": {"price": "cap at bounds"}})
    assert capped["price"].max() < 9999


def test_invalid_custom_value_is_skipped():
    out, log = cl.apply_cleaning(_df(), {"missing": {"price": ("custom value", "abc")}})
    assert out["price"].isna().sum() == 1


def test_blank_strings_become_missing():
    df = pd.DataFrame({"a": ["x", "  ", ""]})
    out, _ = cl.apply_cleaning(df, {"strip_text": True})
    assert out["a"].isna().sum() == 2


def test_flagged_rows():
    flag = cl.flagged_rows(_df())
    assert flag.sum() == 4  # 2 rows with missing values + 2 outlier rows (one also a duplicate)
