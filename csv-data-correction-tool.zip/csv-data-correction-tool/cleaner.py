"""Core data-cleaning logic (no Streamlit code here, so it is easy to test)."""
import pandas as pd

TEXT_CASES = ["keep", "lower", "upper", "title"]
MISSING_NUMERIC = ["leave", "drop rows", "mean", "median", "mode", "custom value"]
MISSING_TEXT = ["leave", "drop rows", "mode", "custom value"]
OUTLIER_ACTIONS = ["leave", "remove rows", "cap at bounds"]


def column_types(df):
    """Return (numeric_columns, text_columns). Dates and booleans are left alone."""
    numeric, text = [], []
    for col in df.columns:
        s = df[col]
        if pd.api.types.is_bool_dtype(s) or pd.api.types.is_datetime64_any_dtype(s):
            continue
        if pd.api.types.is_numeric_dtype(s):
            numeric.append(col)
        else:
            text.append(col)
    return numeric, text


def iqr_bounds(series, k=1.5):
    """Outlier bounds using the IQR rule. Returns None if they can't be computed."""
    s = series.dropna()
    if s.empty:
        return None
    q1, q3 = s.quantile(0.25), s.quantile(0.75)
    iqr = q3 - q1
    if iqr == 0:
        return None
    return q1 - k * iqr, q3 + k * iqr


def outlier_mask(series, k=1.5):
    bounds = iqr_bounds(series, k)
    if bounds is None:
        return pd.Series(False, index=series.index)
    low, high = bounds
    return (series < low) | (series > high)  # NaN compares as False


def profile(df):
    """Summarise data quality: counts plus a per-column table."""
    numeric, _ = column_types(df)
    numeric_set = set(numeric)
    table = pd.DataFrame(
        {
            "column": df.columns,
            "type": ["numeric" if c in numeric_set else "text/other" for c in df.columns],
            "missing": df.isna().sum().values,
            "missing_%": (df.isna().mean() * 100).round(1).values,
            "unique": df.nunique().values,
        }
    )
    table["outliers"] = [int(outlier_mask(df[c]).sum()) if c in numeric_set else 0 for c in df.columns]
    return {
        "rows": len(df),
        "columns": df.shape[1],
        "missing_cells": int(df.isna().sum().sum()),
        "duplicate_rows": int(df.duplicated().sum()),
        "outliers": int(table["outliers"].sum()),
        "table": table,
    }


def flagged_rows(df):
    """Boolean Series: True for rows with a missing value, a duplicate, or an outlier."""
    numeric, _ = column_types(df)
    flag = df.isna().any(axis=1) | df.duplicated(keep="first")
    for col in numeric:
        flag |= outlier_mask(df[col])
    return flag


def apply_cleaning(df, options):
    """Apply the chosen fixes. Returns (cleaned_df, change_log).

    options = {
        "strip_text": bool,
        "text_case": "keep" | "lower" | "upper" | "title",
        "drop_duplicates": bool,
        "missing":  {column: (strategy, custom_value)},
        "outliers": {column: action},
    }
    """
    df = df.copy()
    log = []

    def record(step, column, rows, detail=""):
        if rows:
            log.append({"step": step, "column": column, "rows_affected": int(rows), "detail": detail})

    _, text_cols = column_types(df)

    # 1) text: trim spaces, turn blanks into missing, optionally change case
    if options.get("strip_text"):
        for col in text_cols:
            before = df[col].copy()
            mask = df[col].notna()
            df.loc[mask, col] = df.loc[mask, col].astype(str).str.strip()
            df[col] = df[col].replace("", pd.NA)
            changed = (before.fillna("<NA>") != df[col].fillna("<NA>")).sum()
            record("trim whitespace / blank to missing", col, changed)

    case = options.get("text_case", "keep")
    if case != "keep":
        for col in text_cols:
            before = df[col].copy()
            mask = df[col].notna()
            converted = df.loc[mask, col].astype(str)
            df.loc[mask, col] = getattr(converted.str, case)()
            changed = (before.fillna("<NA>") != df[col].fillna("<NA>")).sum()
            record(f"convert to {case} case", col, changed)

    # 2) duplicate rows
    if options.get("drop_duplicates"):
        n = len(df)
        df = df.drop_duplicates()
        record("drop duplicate rows", "(all columns)", n - len(df))

    # 3) missing values
    for col, (strategy, custom) in options.get("missing", {}).items():
        if col not in df.columns or strategy == "leave":
            continue
        n_missing = int(df[col].isna().sum())
        if n_missing == 0:
            continue
        if strategy == "drop rows":
            df = df[df[col].notna()]
            record("drop rows with missing", col, n_missing)
            continue
        if strategy == "mean":
            value = df[col].mean()
        elif strategy == "median":
            value = df[col].median()
        elif strategy == "mode":
            modes = df[col].mode()
            value = modes.iloc[0] if not modes.empty else None
        elif strategy == "custom value":
            value = pd.to_numeric(custom, errors="coerce") if col in column_types(df)[0] else custom
            if pd.isna(value) or value == "":
                record("fill missing", col, 0, "skipped: invalid custom value")
                continue
        else:
            continue
        if value is None or pd.isna(value):
            continue
        df[col] = df[col].fillna(value)
        record(f"fill missing ({strategy})", col, n_missing, f"value = {value}")

    # 4) outliers (bounds computed on the data as it is at this point)
    for col, action in options.get("outliers", {}).items():
        if col not in df.columns or action == "leave":
            continue
        bounds = iqr_bounds(df[col])
        if bounds is None:
            continue
        mask = outlier_mask(df[col])
        n_out = int(mask.sum())
        if n_out == 0:
            continue
        low, high = bounds
        if action == "remove rows":
            df = df[~mask]
            record("remove outlier rows", col, n_out, f"outside [{low:.2f}, {high:.2f}]")
        elif action == "cap at bounds":
            df[col] = df[col].clip(lower=low, upper=high)
            record("cap outliers", col, n_out, f"capped to [{low:.2f}, {high:.2f}]")

    return df, pd.DataFrame(log, columns=["step", "column", "rows_affected", "detail"])
