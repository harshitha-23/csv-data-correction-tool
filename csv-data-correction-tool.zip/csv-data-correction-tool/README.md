# CSV Data Correction Tool (Streamlit)

A web app where you upload a messy CSV, see its data-quality problems, choose how to fix each one, review exactly what changed, and download the cleaned file plus a change log.

![App screenshot](screenshot.png)
*(add your screenshot here)*

## Problem
Analysts lose hours fixing the same data problems by hand: duplicates, blanks, inconsistent text ("brooklyn ", "BROOKLYN"), and extreme values. This tool makes those fixes visible, repeatable, and documented.

## Features
- **Profile:** rows, columns, missing cells, duplicate rows, and outliers (IQR rule), plus a per-column summary.
- **Clean:** trim spaces, treat blanks as missing, standardize text case, drop duplicates, handle missing values per column (drop rows, mean, median, mode, or custom value), and handle outliers per column (leave, remove rows, or cap at bounds).
- **Manual fixes:** edit the remaining flagged rows directly in the browser.
- **Audit trail:** before/after metrics and a change log of every fix, both downloadable.

## Run it
```bash
pip install -r requirements.txt
streamlit run app.py
python -m pytest        # unit tests for the cleaning logic
```
The app starts with a built-in synthetic sample. For a more impressive demo, upload a real messy dataset, for example [NYC 311 Service Requests](https://data.cityofnewyork.us/Social-Services/311-Service-Requests-from-2010-to-Present/erm2-nwe9) (export a sample as CSV).

## Project structure
```
app.py              Streamlit interface
cleaner.py          cleaning logic (no UI code, so it is testable)
generate_sample.py  creates data/sample_messy.csv (synthetic)
tests/              pytest tests for cleaner.py
```

## Design decisions
- Cleaning logic is separate from the UI so it can be unit tested.
- Every change is logged, so the output is auditable.
- Outlier bounds use the IQR rule and are computed after earlier fixes, so removed duplicates don't distort them.
- Outliers are flagged and the user chooses what to do; nothing is deleted automatically.

## Deploy for free (optional, gives you a live link for your resume)
Push the repo to GitHub, then deploy it on [Streamlit Community Cloud](https://streamlit.io/cloud) by selecting the repo and `app.py`.

## Skills demonstrated
Python, pandas, Streamlit, data profiling and cleaning, IQR outlier detection, separation of concerns, pytest, documentation.
