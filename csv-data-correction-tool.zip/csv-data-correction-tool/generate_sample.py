"""Create data/sample_messy.csv: a SYNTHETIC service-request dataset with deliberate errors."""
import random
from datetime import date, timedelta
from pathlib import Path

import pandas as pd

random.seed(7)
N = 500
boroughs = ["Brooklyn", "Queens", "Manhattan", "Bronx", "Staten Island"]
complaints = ["Noise", "Heating", "Street Light", "Pothole", "Graffiti", "Water Leak"]
agencies = ["NYPD", "HPD", "DOT", "DEP", "DSNY"]

rows = []
for i in range(N):
    borough = random.choice(boroughs)
    r = random.random()
    if r < 0.10:
        borough = borough.lower() + " "          # inconsistent case + trailing space
    elif r < 0.18:
        borough = borough.upper()
    elif r < 0.22:
        borough = ""                              # blank
    hours = round(random.lognormvariate(2.5, 0.6), 1)
    if random.random() < 0.02:
        hours = random.choice([999.0, 5000.0, 9999.0])   # outliers
    if random.random() < 0.06:
        hours = None
    rows.append(
        {
            "request_id": 100000 + i,
            "created_date": (date(2024, 1, 1) + timedelta(days=random.randint(0, 364))).isoformat(),
            "borough": borough,
            "complaint_type": random.choice(complaints),
            "agency": random.choice(agencies) if random.random() > 0.05 else None,
            "response_hours": hours,
            "status": random.choice(["Closed", "Open", "closed", "Pending"]),
        }
    )

df = pd.DataFrame(rows)
df = pd.concat([df, df.sample(25, random_state=3)], ignore_index=True)   # duplicate rows
Path("data").mkdir(exist_ok=True)
df.to_csv("data/sample_messy.csv", index=False)
print(f"wrote data/sample_messy.csv ({len(df)} rows)")
