"""CSV Data Correction Tool: upload a CSV, find data-quality problems, fix them, download the result.

Run with:  streamlit run app.py
"""
import hashlib
import io
import json
from pathlib import Path

import pandas as pd
import streamlit as st

import cleaner as cl

SAMPLE_PATH = Path(__file__).parent / "data" / "sample_messy.csv"

st.set_page_config(page_title="CSV Data Correction Tool", layout="wide")
st.title("CSV Data Correction Tool")
st.caption("Profile a messy CSV, choose how to fix each problem, review the changes, and download clean data.")


@st.cache_data
def load_csv(raw_bytes):
    try:
        return pd.read_csv(io.BytesIO(raw_bytes))
    except UnicodeDecodeError:
        return pd.read_csv(io.BytesIO(raw_bytes), encoding="latin-1")


def to_csv_bytes(frame):
    return frame.to_csv(index=False).encode("utf-8")


# ---------- sidebar: choose data ----------
with st.sidebar:
    st.header("1. Data")
    source = st.radio("Data source", ["Sample data", "Upload CSV"])
    uploaded = st.file_uploader("CSV file", type="csv") if source == "Upload CSV" else None

if source == "Upload CSV":
    if uploaded is None:
        st.info("Upload a CSV file in the sidebar, or switch to the sample data.")
        st.stop()
    try:
        original = load_csv(uploaded.getvalue())
    except Exception as exc:  # unreadable or empty file
        st.error(f"Could not read this file as CSV: {exc}")
        st.stop()
else:
    original = load_csv(SAMPLE_PATH.read_bytes())
    st.sidebar.caption("Synthetic sample: service requests with deliberate errors.")

if original.empty:
    st.warning("The file has no rows.")
    st.stop()

numeric_cols, text_cols = cl.column_types(original)
tab_profile, tab_clean, tab_manual, tab_download = st.tabs(
    ["1. Profile", "2. Clean", "3. Manual fixes", "4. Download"]
)

# ---------- tab 1: profile ----------
with tab_profile:
    p = cl.profile(original)
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Rows", f"{p['rows']:,}")
    c2.metric("Columns", p["columns"])
    c3.metric("Missing cells", f"{p['missing_cells']:,}")
    c4.metric("Duplicate rows", f"{p['duplicate_rows']:,}")
    c5.metric("Outliers (IQR)", f"{p['outliers']:,}")
    st.subheader("Columns")
    st.dataframe(p["table"], hide_index=True)
    st.subheader("Preview")
    st.dataframe(original.head(100))

# ---------- tab 2: clean ----------
with tab_clean:
    st.subheader("Choose fixes")
    left, right = st.columns(2)
    with left:
        drop_dups = st.checkbox("Drop duplicate rows", value=True, key="drop_dups")
        strip_text = st.checkbox("Trim spaces and treat blanks as missing", value=True, key="strip_text")
        text_case = st.selectbox("Text case", cl.TEXT_CASES, index=0, key="text_case")
    with right:
        st.caption("Outliers use the IQR rule (below Q1 - 1.5 x IQR or above Q3 + 1.5 x IQR).")

    missing_opts, outlier_opts = {}, {}
    cols_with_missing = [c for c in original.columns if original[c].isna().any() or strip_text]
    st.markdown("**Missing values**")
    for col in cols_with_missing:
        choices = cl.MISSING_NUMERIC if col in numeric_cols else cl.MISSING_TEXT
        if col not in numeric_cols and col not in text_cols:
            continue
        a, b = st.columns([2, 1])
        strategy = a.selectbox(f"{col}", choices, key=f"missing_{col}")
        custom = b.text_input("Value", key=f"custom_{col}", disabled=strategy != "custom value")
        missing_opts[col] = (strategy, custom)

    st.markdown("**Outliers**")
    shown = False
    for col in numeric_cols:
        n_out = int(cl.outlier_mask(original[col]).sum())
        if n_out:
            shown = True
            outlier_opts[col] = st.selectbox(f"{col} ({n_out} outliers)", cl.OUTLIER_ACTIONS, key=f"outlier_{col}")
    if not shown:
        st.caption("No numeric outliers found.")

    options = {
        "drop_duplicates": drop_dups,
        "strip_text": strip_text,
        "text_case": text_case,
        "missing": missing_opts,
        "outliers": outlier_opts,
    }
    cleaned, change_log = cl.apply_cleaning(original, options)

    st.subheader("Before vs after")
    before, after = cl.profile(original), cl.profile(cleaned)
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Rows", f"{after['rows']:,}", f"{after['rows'] - before['rows']:,}")
    m2.metric("Missing cells", f"{after['missing_cells']:,}", f"{after['missing_cells'] - before['missing_cells']:,}", delta_color="inverse")
    m3.metric("Duplicate rows", f"{after['duplicate_rows']:,}", f"{after['duplicate_rows'] - before['duplicate_rows']:,}", delta_color="inverse")
    m4.metric("Outliers", f"{after['outliers']:,}", f"{after['outliers'] - before['outliers']:,}", delta_color="inverse")

    st.subheader("Change log")
    if change_log.empty:
        st.caption("No changes yet. Pick some fixes above.")
    else:
        st.dataframe(change_log, hide_index=True)

# ---------- tab 3: manual fixes ----------
signature = hashlib.md5(json.dumps(options, sort_keys=True, default=str).encode()).hexdigest()[:8]
final = cleaned.copy()
with tab_manual:
    st.write("Rows that still have a missing value, a duplicate, or an outlier. Edit cells directly.")
    st.caption("Manual edits reset if you change the automatic fixes in step 2.")
    flag = cl.flagged_rows(cleaned)
    subset = cleaned[flag].head(300)
    st.write(f"{int(flag.sum()):,} flagged rows (showing up to 300).")
    if subset.empty:
        st.success("Nothing left to review.")
    else:
        edited = st.data_editor(subset, num_rows="fixed", key=f"editor_{signature}")
        final.loc[edited.index, edited.columns] = edited
        n_edits = int((edited.fillna("<NA>").astype(str) != subset.fillna("<NA>").astype(str)).any(axis=1).sum())
        st.caption(f"{n_edits} row(s) edited manually.")

# ---------- tab 4: download ----------
with tab_download:
    st.write(f"Final dataset: **{len(final):,} rows** x {final.shape[1]} columns")
    st.dataframe(final.head(100))
    d1, d2 = st.columns(2)
    d1.download_button("Download cleaned CSV", to_csv_bytes(final), "cleaned_data.csv", "text/csv")
    d2.download_button("Download change log", to_csv_bytes(change_log), "change_log.csv", "text/csv", disabled=change_log.empty)
